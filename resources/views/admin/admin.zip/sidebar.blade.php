<div class="col-md-3">
    <ul class="list-group">
        <li class="list-group-item list-group-link">
            <a href="{{ route('admin') }}">Statistik</a>
        </li>
        <li class="list-group-item list-group-link">
            <a href="{{ route('admin.users') }}">User</a>
        </li>
        <li class="list-group-item list-group-link">
            <a href="{{ route('admin.comments') }}">Komentar</a>
        </li>
        <li class="list-group-item list-group-link">
            <a href="{{ route('admin.recipes') }}">Resep</a>
        </li>
        <li class="list-group-item list-group-link">
            <a href="{{ route('admin.categories') }}">Kategori</a>
        </li>
        <li class="list-group-item list-group-link">
            <a href="{{ route('admin.ingredients') }}">Bahan Baku</a>
        </li>
        <li class="list-group-item list-group-link">
            <a href="{{ route('admin.spices') }}">Bumbu</a>
        </li>
    </ul>
</div>
